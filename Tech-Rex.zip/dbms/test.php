<?php
//date_default_timezone_set('Asia/Calcutta');
$dt = date('d/m/Y');
echo date_default_timezone_get();
echo $dt;
?>