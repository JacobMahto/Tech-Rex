<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Hello</title>
    </head>
    <body>
         <script>window.location = 'login.php';</script>
        
    </body>
</html>
